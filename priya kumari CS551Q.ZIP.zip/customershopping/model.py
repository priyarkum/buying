rom django.db import models

# Create your models here.
from django.conf import settings
from django.db import models
 



class shoppingydata(models.Model):
    customerid = models.TextField(primary_key=True)
    invoiceno = models.TextField()
    catageory = models.TextField()
    quantity = models.TextField()

    def str(self):
        return f'{self.customerid}, {self.invoiceno}, {self.catageory}, {self.quantity}'


class value(models.Model):
    customerid = models.TextField(primary_key=True)
    price = models.ForeignKey('consumerapp.shoppingdata', on_delete=models.CASCADE, related_name='values')
    invoicedate = models.TextField()
    paymentmethod= models.TextField()
    shoppingmall = models.TextField()

        def str(self):
        return f'{self.customerid}, {self.price}, {self.invoicedate}, {self.paymentmethod}, {self.shoppingmall}'