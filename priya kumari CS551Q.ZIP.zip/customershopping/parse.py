port csv
import os
from pathlib import Path
from django.db import models
from django.core.management.base import BaseCommand, CommandError

from consumerapp.models import shoppingdata, value

class Command(BaseCommand):
    help = 'Load data from csv'

    def handle(self, *args, **options):

        # drop the data from the table so that if we rerun the file, we don't repeat values
        shoppingdata.objects.all().delete()
        value.objects.all().delete()
        print("table dropped successfully")
        # create table again

        # open the file to read it into the database
        base_dir = Path(file).resolve().parent.parent.parent.parent
        with open(str(base_dir) + '/consumerapp/csvfile/shoppingdata.csv', newline='') as f:
            reader = csv.reader(f, delimiter=",")
            next(reader) # skip the header line
            for row in reader:
                print(row)
                table1 = shoppingdata.objects.create(
                customerid = row[1],    
                invoiceNo = row[0],
                catageory = row[4],
                quantity = row[5],
                age = row[3]
                )
                table1.save()
        

        with open(str(base_dir) + '/consumerapp/csvfile/shoppingdata.csv', newline='') as f:
            reader = csv.reader(f, delimiter=",")
            next(reader) # skip the header line
            for row in reader:
                print(row)

                table2 = value.objects.create(
                customerid = row[1],
                price = consumerdata.objects.filter(customerid = row[1]).first(),
                paymentmethod = row[7],
                invoicedate = row[8],
                gender = row[2],
                )
                table2.save()
        print("data parsed successfully")