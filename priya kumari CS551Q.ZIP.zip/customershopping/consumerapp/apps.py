from django.apps import AppConfig


class ConsumerappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consumerapp'
