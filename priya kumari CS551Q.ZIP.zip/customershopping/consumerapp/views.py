from django.shortcuts import render
def shops(request):
    context = {}
    return render(request, 'shops/shops.html', context)

def cart(request):
    context = {}
    return render(request, 'shops/cart.html', context)

def checkout(request):
    context = {}
    return render(request, 'shops/checkout.html', context)